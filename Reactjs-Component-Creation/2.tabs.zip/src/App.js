import './App.css';
import { useState } from 'react';
function App() {

  const [getTab, setTab] = useState([
    { tab: 'TAB1', content: "box1" },
    { tab: 'TAB2', content: "box2" },
    { tab: 'TAB3', content: "box3" },
    { tab: 'TAB1', content: "box4" },
    { tab: 'TAB2', content: "box5" },
    { tab: 'TAB3', content: "box6" }
  ]);
  const[getContent,setContent]=useState(null);

  const onChangeHandler=(index)=>{
    setContent(getTab[index].content);
  }

  return (
    <div className="container">
      <div className="header">
        {getTab.map((obj,index) => {
          return (<div className="map-list" onClick={()=>onChangeHandler(index)}>
            <div className="tab-list">
            {obj.tab}
          </div>
          <div className="slider"></div>
          </div>)
        })}
      </div>
      <div className="box">
       {getContent && getContent}
      </div>
      <div className="footer"></div>
    </div>
  );
}

export default App;
