import "./App.css";
import { useState } from "react";

function App() {
  const [getContent,setContent] = useState({});

  const onClickHandler=()=>{
    setContent({'display':'block'});
  }

  const onOutHandler=()=>{
    setContent({'display':'none'});
  }
  return (
    <div>
        <h1 onMouseOver={onClickHandler} onMouseLeave={onOutHandler}>WHO
             <div style={getContent} className="tooltip">world health organization</div>
        </h1>
    </div>
  );
}
export default App;
