import './App.css';
import {useState} from 'react';

function App(){

  const [getFlag,setFlag] = useState(false);

  const onClickHandler=()=>{
      setFlag(!getFlag);
  }

  return (<div>
    <div className="box">
      <div className={getFlag?'triangle-right':'triangle-left'} onClick={onClickHandler}></div>
    </div>
  </div>)
}
export default App;