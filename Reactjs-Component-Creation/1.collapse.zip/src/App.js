import './App.css';
import { useState } from 'react';
function App() {

  const [getTab, setTab] = useState([
    {

      header: "header 1",
      content: "The content is one"
    },
    {

      header: "header 2",
      content: "The content is two"
    },
    {

      header: "header 3",
      content: "The content is three"
    }
  ]);

  const [getHide, showHide] = useState(-1);

  const onChangeHandler = (index) => {
    showHide(index);
  }

  return (
    <div className="container">
      {getTab.map((obj, index) => {
        return (<div keys={index} className="box">
          <div className="header" onClick={() => onChangeHandler(index)}>
            {getHide === index?<div className="down-arrow"></div>:<div className="right-arrow"></div>}
              {obj.header}
            </div>
          {getHide === index && <div className="content">{obj.content}</div>}
        </div>)
      })}
    </div>
  )
}

export default App;
