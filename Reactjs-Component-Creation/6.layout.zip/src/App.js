import './App.css';
import {useState} from 'react';

function App(){

  const [getDigits,setDigits] = useState('0px');
  const[getFontSize,setFontSize] = useState('10px');

  const onClickHandler=(event)=>{
      // console.log(event.clientX);
      // console.log(event.clientY);
      // console.log(event.target.id);
      if(event.target.id == "circle" && event.clientX >=75 && event.clientX <=200){
        let base = 75;
        let difference = event.clientX - base;
        setDigits(`${difference}px`);
        setFontSize(`${difference}px`);
      }
  }

  return (<div>
    <div className="box">
      <div className="header"></div>
      <div className="content">
          <div className="content-left"></div>
          <div className="content-right"></div>
      </div>
      <div className="footer"></div>
    </div>
  
  </div>)
}
export default App;