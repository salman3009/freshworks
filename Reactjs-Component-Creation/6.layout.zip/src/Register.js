import {useNavigate} from 'react-router-dom';
function Register(){

    const navigate = useNavigate();
    console.log("Register component");
    const onClickDetails=()=>{
        localStorage.setItem("names","register");
        navigate('/');
    }
    return (<div>
         <h1>Register component</h1>
         <button onClick={onClickDetails}>Register</button>
    </div>)
}
export default Register;