import {useNavigate} from 'react-router-dom';

function Login(){
    const navigate = useNavigate();
    console.log("Login component");

    const onClickDetails=()=>{
        localStorage.setItem("names","login");
        navigate('/register')
    }

    return (<div>
         <h1>Login component</h1>
         <button onClick={onClickDetails}>Login</button>
    </div>)
}
export default Login;