import {useNavigate} from 'react-router-dom';

function Header(){

    const navigate = useNavigate();

    console.log("heasder component");
    let result = localStorage.getItem("names");
    console.log(result);
    return (<div>
        <h1>{result}</h1>
         <h1>Header component</h1>
    </div>)
}
export default Header;