import "./App.css";
import { useState } from "react";

function App() {
  const [getModal, setModal] = useState({"left":"0px","top":"0px"});

  const onClickHandler = (type) => {
    if(type === "left"){
      setModal({"left":"0px","top":"0px","marginLeft":"10px"});
    }
    else if(type === "right"){
      setModal({"right":"0px","top":"0px","marginRight":"10px"});
    }
  };

  return (
    <div>
      {getModal && <div style={getModal} className="modal">
          <div className="content">
              <h6>header modal</h6>
          </div>
      </div>
      }
      <button onClick={()=>onClickHandler("left")}>Notification left</button>
      <button onClick={()=>onClickHandler("right")}>Notification right</button>
   
    </div>
  );
}
export default App;
